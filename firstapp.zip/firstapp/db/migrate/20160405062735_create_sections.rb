class CreateSections < ActiveRecord::Migration
  def change
    create_table :sections do |t|

		t.integer "page_id"
		# same as: t.references :page_id
		t.string "name"
		t.integer "position"
		t.boolean "visible",:default=> false
		t.string "content_Type"
		t.text "content"
		t.timestamps
    end
	add_index("sections","page_id")
  end
end
