module SubjectsHelper
	
end	