class MobileController < ApplicationController
  def index
  end

  def show
  end

  def edit
  end
end
