class AdminUsersController < ApplicationController
  
  layout 'Admin'
  
  before_action :confirm_logged_in
  
  def index
	@admin_users = AdminUser.sorted
	
	
	def self.print  
	
	require 'json'
	respond_to do |format|
	format.html #index.html.erb
	format.json { render json: @admin_users }
	end    
		
  end

  def new
	@admin_users = AdminUser.new
  end
  
  def create
	@admin_user = AdminUser.new(admin_user_params)
	if @admin_user.save
		flash[:notice] = 'Admin user created.'
		redirect_to(:action => 'index')
	else
		render("new")
	end	
  end

  def edit
	@admin_user = AdminUser.find(params[:id])
  end
  
  def update
	@admin_user = AdminUser.find(params[:id])
	if @admin_user.update_attributes(admin_user_params)
		flash[:notice] = 'Admin user updated.'
		redirect_to(:action => 'index')
	else
		render("edit")
	end	
  end

  def delete
	@admin_user = AdminUser.find(params[:id])
  end
  
  def destroy
	AdminUser.find(params[:id]).destroy
	flash[:notice] = "Admin user destroyed."
	redirect_to(:action => 'index')
  end
  
 
  
  private
  
  def confirm_logged_in
	unless session[:user_id]
		flash[:notice] = "Please log in."
		redirect_to(:action => 'login')
		return false # halts the before_action
	else
		return true
  end
end
  
  
  def admin_user_params
	params.require(:admin_user).permit(:first_name, :last_name, :email, :username, :password)
  end
  
end
