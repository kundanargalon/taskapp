class Test < ApplicationController
  
  def index
    ActiveRecord::Base.connection.select_values("SELECT name FROM subjects")
  end
  
end
