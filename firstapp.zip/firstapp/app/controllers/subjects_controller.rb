class SubjectsController < ApplicationController
  
  layout "Admin"
  
  def index
  @subjects = Subject.sorted
  end

  def show
  @subject = Subject.find(params[:id])
  end

  def new
  @subject = Subject.new({:name => "Default"})
  @subject_count = Subject.count + 1
  end
  
  def create
 # instantiate a new object using form parameters
   @subject = Subject.new(params[:id])
   @subject = Subject.new(subjects_params)
 # Save the object
	if @subject.save
 # if save succeds, redirect to index
	flash[:notice] = "Subject created succesfully."
	redirect_to(:action => 'index')
	else
 #if save fails, redisplay the form so user can fix problems
	@subject_count = Subject.count + 1
	render('new')
  end
end  

  def edit
  @subject = Subject.find(params[:id])
  @subject_count = Subject.count 
  end

  def update
 # instantiate a new object using form parameters
   @subject = Subject.find(params[:id])
   
 # Update the object  
   
   if @subject.update_attributes(subjects_params)
 
 # if update succeds, redirect to index
	flash[:notice] = "Subject updated succesfully"
	redirect_to(:action => 'show', :id => @subject.id)
	else 
 #if update fails, redisplay the form so user can fix problems
	@subject_count = Subject.count
	render('edit')
  end
end 
  
  def delete 
	@subject = Subject.find(params[:id])
  end
  
  def delete 
	subject = Subject.find(params[:id]).destroy
	flash[:notice] = "Subject '#{subject.name}' destroyed succesfully"
	redirect_to(:action => 'index')
  end
  
  
  
  private
   
   def subjects_params
	params.require(:subject).permit(:name, :position, :visible, :created_at)
   end
  
  
end
